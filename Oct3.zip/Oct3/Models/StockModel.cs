﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_XYZ_Apparels.Models
{
    public class StockModel
    {
        [Display(Name = "Fabric ID")]
        public int FabricID { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Supplier Name")]
        public string SupplierName { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Fabric Type")]
        public string FabricType { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Design Number")]
        public string DesignNo { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Rate Per Meter")]
        public int RatePerMeter { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Stock In Meter")]
        public int StockInMeter { get; set; }

        [Display(Name = "Fabric Image Address")]
        public string FabricImageAddress { get; set; }

    }
}