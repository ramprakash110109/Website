﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_XYZ_Apparels.Models
{
    public class CustomerModel
    {
        public int CustomerID { get; set; }

        [StringLength(15, MinimumLength = 5, ErrorMessage = "15 Chars Only")]
        public string CustomerName { get; set; }

        [StringLength(50, MinimumLength = 5, ErrorMessage = "50 Chars Only")]
        public string CustomerAddress { get; set; }

        [StringLength(50, MinimumLength = 5, ErrorMessage = "50 Chars Only")]
        public string CustomerWebsite { get; set; }
        
        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string CustomerEmailID { get; set; }

        public string CustomerLandline { get; set; }

        [StringLength(50, MinimumLength = 5, ErrorMessage = "50 Chars Only")]
        public string CustomerContactName1 { get; set; }

        [RegularExpression("^[7-9][0-9]{9}$", ErrorMessage = "Only 10 Numbers")]
        public string CustomerContactNumber1 { get; set; }

        [StringLength(50, MinimumLength = 5, ErrorMessage = "50 Chars Only")]
        public string CustomerContactName2 { get; set; }

        [RegularExpression("^[7-9][0-9]{9}$", ErrorMessage = "Only 10 Numbers")]
        public string CustomerContactNumber2 { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Min Rs 0")]
        public int CustomerDue { get; set; }
        public string CustomerStatus { get; set; }
    }

}