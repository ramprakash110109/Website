﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using Mvc_XYZ_Apparels.Models;
using System.Web.Mvc;

namespace Mvc_XYZ_Apparels.Models
{
    public class StocksDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool InsertFabric(StockModel obj)
        {
            if (obj.FabricImageAddress == null)
                obj.FabricImageAddress = "/Content/Images/pos.jpg";

            SqlCommand com_stock_insert = new SqlCommand
            (@"insert Fabrics values(@SupplierName,@MillName,@FabricType,@DesignNo,@RatePerMeter,@StockInMeter,null)", con);
            com_stock_insert.Parameters.AddWithValue("@SupplierName", obj.SupplierName);
            com_stock_insert.Parameters.AddWithValue("@MillName", obj.MillName);
            com_stock_insert.Parameters.AddWithValue("@FabricType", obj.FabricType);
            com_stock_insert.Parameters.AddWithValue("@DesignNo", obj.DesignNo);
            com_stock_insert.Parameters.AddWithValue("@RatePerMeter", obj.RatePerMeter);
            com_stock_insert.Parameters.AddWithValue("@StockInMeter", obj.StockInMeter);

            con.Open();
            SqlTransaction tran=con.BeginTransaction();
            com_stock_insert.Transaction=tran;
            com_stock_insert.ExecuteNonQuery();

            SqlCommand com_fabricid = new SqlCommand("Select @@identity", con);
            com_fabricid.Transaction=tran;
            obj.FabricID = Convert.ToInt32(com_fabricid.ExecuteScalar());

            obj.FabricImageAddress = "/Content/Images/" + obj.FabricID + ".jpg";
            SqlCommand com_image_upload = new SqlCommand(@"update Fabrics set FabricImageAddress=@FabricImageAddress where FabricID=@FabricID", con);
            com_image_upload.Parameters.AddWithValue("@FabricImageAddress",obj.FabricImageAddress);
            com_image_upload.Parameters.AddWithValue("@FabricID",obj.FabricID);
            com_image_upload.Transaction=tran;
            com_image_upload.ExecuteNonQuery();
            if (obj.FabricImageAddress != null)
            {
                tran.Commit();
                con.Close();
                return true;
            }
            tran.Rollback();
            con.Close();
            return false;
        }

        public StockModel FindFabric(int ID)
        {
            SqlCommand com_read_fabric = new SqlCommand(@"Select * from Fabrics where FabricID=@FabricID", con);
            com_read_fabric.Parameters.AddWithValue("@FabricID", ID);

            con.Open();

            SqlDataReader dr_fabrics = com_read_fabric.ExecuteReader();
            StockModel model = new StockModel();
            if (dr_fabrics.Read())
            {
                model.FabricID = ID;
                model.SupplierName = dr_fabrics.GetString(1);
                model.MillName = dr_fabrics.GetString(2);
                model.FabricType = dr_fabrics.GetString(3);
                model.DesignNo = dr_fabrics.GetString(4);
                model.RatePerMeter = dr_fabrics.GetInt32(5);
                model.StockInMeter = dr_fabrics.GetInt32(6);
                model.FabricImageAddress = dr_fabrics.GetString(7);
            }
            else
                model = null;
            con.Close();
            return model;
        }

        public bool UpdateFabric(StockModel obj)
        {
            if (obj.FabricImageAddress == null)
                obj.FabricImageAddress = "~/Content/Images/pos.png";

            SqlCommand com_update_fabric = new SqlCommand
                     (@"update Fabrics set SupplierName=@SupplierName,MillName=@MillName,FabricType=@FabricType,DesignNo=@DesignNo,RatePerMeter=@RatePerMeter,
StockInMeter=@StockInMeter,FabricImageAddress=@FabricImageAddress where FabricID=@FabricID", con);

            com_update_fabric.Parameters.AddWithValue("@SupplierName", obj.SupplierName);
            com_update_fabric.Parameters.AddWithValue("@MillName", obj.MillName);
            com_update_fabric.Parameters.AddWithValue("@FabricType", obj.FabricType);
            com_update_fabric.Parameters.AddWithValue("@DesignNo", obj.DesignNo);
            com_update_fabric.Parameters.AddWithValue("@RatePerMeter", obj.RatePerMeter);
            com_update_fabric.Parameters.AddWithValue("@StockInMeter", obj.StockInMeter);
            com_update_fabric.Parameters.AddWithValue("@FabricImageAddress", obj.FabricImageAddress);
            com_update_fabric.Parameters.AddWithValue("@FabricID", obj.FabricID);

            con.Open();
            int count = com_update_fabric.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<StockModel> GetFabrics()
        {
            List<StockModel> list_fabrics = new List<StockModel>();
            SqlCommand com_fabrics = new SqlCommand("Select * from Fabrics", con);
            con.Open();
            SqlDataReader dr_fabrics = com_fabrics.ExecuteReader();
            while (dr_fabrics.Read())
            {
                StockModel model = new StockModel();
                model.FabricID = dr_fabrics.GetInt32(0);
                model.SupplierName = dr_fabrics.GetString(1);
                model.MillName = dr_fabrics.GetString(2);
                model.FabricType = dr_fabrics.GetString(3);
                model.DesignNo = dr_fabrics.GetString(4);
                model.RatePerMeter = dr_fabrics.GetInt32(5);
                model.StockInMeter = dr_fabrics.GetInt32(6);
                model.FabricImageAddress = dr_fabrics.GetString(7);
                list_fabrics.Add(model);
            }
            con.Close();
            return list_fabrics;
        }

        public List<SelectListItem> GetShirtingDescription()
        {
            List<SelectListItem> list_description = new List<SelectListItem>();

            SqlCommand com_description = new SqlCommand(@"select FabricType,MillName,DesignNo from Fabrics where FabricType='Shirting'", con);
            con.Open();
            SqlDataReader dr_description = com_description.ExecuteReader();

            SelectListItem model1 = new SelectListItem();
            model1.Value = "";
            model1.Text = "Select a Shirting Description";
            list_description.Add(model1);
            while (dr_description.Read())
            {
                SelectListItem model = new SelectListItem();
                model.Value = (dr_description.GetString(0) +" - "+ dr_description.GetString(1)+" - " + dr_description.GetString(2)).ToString();
                model.Text = (dr_description.GetString(0) + " - " + dr_description.GetString(1) + " - " + dr_description.GetString(2)).ToString();
                list_description.Add(model);
            }
            con.Close();
            return list_description;
        }

        public List<SelectListItem> GetSuitingDescription()
        {
            List<SelectListItem> list_description = new List<SelectListItem>();

            SqlCommand com_description = new SqlCommand(@"select FabricType,MillName,DesignNo from Fabrics where FabricType='Suiting'", con);
            con.Open();
            SqlDataReader dr_description = com_description.ExecuteReader();

            SelectListItem model1 = new SelectListItem();
            model1.Value = "";
            model1.Text = "Select a Shirting Description";
            list_description.Add(model1);
            while (dr_description.Read())
            {
                SelectListItem model = new SelectListItem();
                model.Value = (dr_description.GetString(0) + " - " + dr_description.GetString(1) + " - " + dr_description.GetString(2)).ToString();
                model.Text = (dr_description.GetString(0) + " - " + dr_description.GetString(1) + " - " + dr_description.GetString(2)).ToString();
                list_description.Add(model);
            }
            con.Close();
            return list_description;
        }


        
    }
}