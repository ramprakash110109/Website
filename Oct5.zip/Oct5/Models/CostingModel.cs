﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_XYZ_Apparels.Models
{
    public class CostingModel
    {
        public int CostingID { get; set; }
        public string CustomerName { get; set; }
        public string CostingDescription { get; set; }
        public int CostingSize { get; set; }
        public string CostingShirting { get; set; }
        public int CostingShirtingQty { get; set; }
        public string CostingSuiting { get; set; }
        public int CostingSuitingQty { get; set; }
        public int CuttingPrice { get; set; }
        public int SingerPrice { get; set; }
        public int TrimmingPrice { get; set; }
        public int IroningPrice { get; set; }
        public int ActualPrice { get; set; }
        public int Profit { get; set; }
        public int CostingPrice { get; set; }
    }
}