﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_XYZ_Apparels.Models
{
    public class UserModel
    {
        public string UserID { get; set; }
        public string UserPassword { get; set; }
        public bool RememberMe { get; set; }
        public string UserType { get; set; }
        public string UserQuestion { get; set; }
        public string UserAnswer { get; set; }
        public string UserEmailID { get; set; }
    }
}