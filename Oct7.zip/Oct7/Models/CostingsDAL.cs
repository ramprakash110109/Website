﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using Mvc_XYZ_Apparels.Models;

namespace Mvc_XYZ_Apparels.Models
{
    public class CostingsDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool CreateCosting(CostingModel obj)
        {
            SqlCommand com_costing_insert = new SqlCommand
            (@"insert Costing values(@CustomerName,@CostingDescription,@CostingSize,@CostingShirting,@CostingShirtingQty,
@CostingSuiting,@CostingSuitingQty,@CuttingPrice,@SingerPrice,@TrimmingPrice,@IroningPrice,@ActualPrice,@Profit,@CostingPrice)", con);
            com_costing_insert.Parameters.AddWithValue("@CustomerName", obj.CustomerName);
            com_costing_insert.Parameters.AddWithValue("@CostingDescription", obj.CostingDescription);
            com_costing_insert.Parameters.AddWithValue("@CostingSize", obj.CostingSize);
            com_costing_insert.Parameters.AddWithValue("@CostingShirting", obj.CostingShirting);
            com_costing_insert.Parameters.AddWithValue("@CostingShirtingQty", obj.CostingShirtingQty);
            com_costing_insert.Parameters.AddWithValue("@CostingSuiting", obj.CostingSuiting);
            com_costing_insert.Parameters.AddWithValue("@CostingSuitingQty", obj.CostingSuitingQty);
            com_costing_insert.Parameters.AddWithValue("@CuttingPrice", obj.CuttingPrice);
            com_costing_insert.Parameters.AddWithValue("@SingerPrice", obj.SingerPrice);
            com_costing_insert.Parameters.AddWithValue("@TrimmingPrice", obj.TrimmingPrice);
            com_costing_insert.Parameters.AddWithValue("@IroningPrice", obj.IroningPrice);
            com_costing_insert.Parameters.AddWithValue("@ActualPrice", obj.ActualPrice);
            com_costing_insert.Parameters.AddWithValue("@Profit", obj.Profit);
            com_costing_insert.Parameters.AddWithValue("@CostingPrice", obj.CostingPrice);

            con.Open();
            com_costing_insert.ExecuteNonQuery();

            SqlCommand com_costingid = new SqlCommand("Select @@identity", con);

            obj.CostingID = Convert.ToInt32(com_costing_insert.ExecuteScalar());
            con.Close();
            return true;
        }

        public CostingModel FindCosting(int ID)
        {
            SqlCommand com_read_costing = new SqlCommand(@"Select * from Costing where CostingID=@CostingID", con);
            com_read_costing.Parameters.AddWithValue("@CostingID", ID);

            con.Open();

            SqlDataReader dr_costing = com_read_costing.ExecuteReader();
            CostingModel model = new CostingModel();
            if (dr_costing.Read())
            {
                model.CostingID = ID;
                model.CustomerName = dr_costing.GetString(1);
                model.CostingDescription = dr_costing.GetString(2);
                model.CostingSize = dr_costing.GetInt32(3);
                model.CostingShirting = dr_costing.GetString(4);
                model.CostingShirtingQty = dr_costing.GetInt32(5);
                model.CostingSuiting = dr_costing.GetString(6);
                model.CostingSuitingQty = dr_costing.GetInt32(7);
                model.CuttingPrice = dr_costing.GetInt32(8);
                model.SingerPrice = dr_costing.GetInt32(9);
                model.TrimmingPrice = dr_costing.GetInt32(10);
                model.IroningPrice = dr_costing.GetInt32(11);
                model.ActualPrice = dr_costing.GetInt32(12);
                model.Profit = dr_costing.GetInt32(13);
                model.CostingPrice = dr_costing.GetInt32(14);
            }
            else
                model = null;
            con.Close();
            return model;
        }

        public bool UpdateCosting(CostingModel obj)
        {

            SqlCommand com_update_Costing = new SqlCommand
                (@"update Costing set CustomerName=@CustomerName,CostingDescription=@CostingDescription,
CostingSize=@CostingSize,CostingShirting=@CostingShirting,CostingShirtingQty=@CostingShirtingQty,
CostingSuiting=@CostingSuiting,CostingSuitingQty=@CostingSuitingQty,
CuttingPrice=@CuttingPrice,SingerPrice=@SingerPrice,TrimmingPrice=@TrimmingPrice,IroningPrice=@IroningPrice,ActualPrice=@ActualPrice,
Profit=@Profit,CostingPrice=@CostingPrice where CostingID=@CostingID", con);
            com_update_Costing.Parameters.AddWithValue("@CustomerName", obj.CustomerName);
            com_update_Costing.Parameters.AddWithValue("@CostingDescription", obj.CostingDescription);
            com_update_Costing.Parameters.AddWithValue("@CostingSize", obj.CostingSize);
            com_update_Costing.Parameters.AddWithValue("@CostingShirting", obj.CostingShirting);
            com_update_Costing.Parameters.AddWithValue("@CostingShirtingQty", obj.CostingShirtingQty);
            com_update_Costing.Parameters.AddWithValue("@CostingSuiting", obj.CostingSuiting);
            com_update_Costing.Parameters.AddWithValue("@CostingSuitingQty", obj.CostingSuitingQty);
            com_update_Costing.Parameters.AddWithValue("@CuttingPrice", obj.CuttingPrice);
            com_update_Costing.Parameters.AddWithValue("@SingerPrice", obj.SingerPrice);
            com_update_Costing.Parameters.AddWithValue("@TrimmingPrice", obj.TrimmingPrice);
            com_update_Costing.Parameters.AddWithValue("@IroningPrice", obj.IroningPrice);
            com_update_Costing.Parameters.AddWithValue("@ActualPrice", obj.ActualPrice);
            com_update_Costing.Parameters.AddWithValue("@Profit", obj.Profit);
            com_update_Costing.Parameters.AddWithValue("@CostingPrice", obj.CostingPrice);
            com_update_Costing.Parameters.AddWithValue("@CostingID", obj.CostingID);

            con.Open();
            int count = com_update_Costing.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<CostingModel> GetCosting()
        {
            List<CostingModel> list_costing = new List<CostingModel>();
            SqlCommand com_costing = new SqlCommand("Select * from Costing", con);
            con.Open();
            SqlDataReader dr_costing = com_costing.ExecuteReader();
            while (dr_costing.Read())
            {
                CostingModel model = new CostingModel();
                model.CostingID = dr_costing.GetInt32(0);
                model.CustomerName = dr_costing.GetString(1);
                model.CostingDescription = dr_costing.GetString(2);
                model.CostingSize = dr_costing.GetInt32(3);
                model.CostingShirting = dr_costing.GetString(4);
                model.CostingShirtingQty = dr_costing.GetInt32(5);
                model.CostingSuiting = dr_costing.GetString(6);
                model.CostingSuitingQty = dr_costing.GetInt32(7);
                model.CuttingPrice = dr_costing.GetInt32(8);
                model.SingerPrice = dr_costing.GetInt32(9);
                model.TrimmingPrice = dr_costing.GetInt32(10);
                model.IroningPrice = dr_costing.GetInt32(11);
                model.ActualPrice = dr_costing.GetInt32(12);
                model.Profit = dr_costing.GetInt32(13);
                model.CostingPrice = dr_costing.GetInt32(14);
                list_costing.Add(model);
            }
            con.Close();
            return list_costing;
        }

    }
}