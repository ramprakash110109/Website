﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_XYZ_Apparels.Models
{
    public class LoginModel
    {
        public string UserID { get; set; }
        [DataType(DataType.Password)]
        public string UserPassword { get; set; }
        public bool RememberMe { get; set; }
        public string UserType { get; set; }
    }
}