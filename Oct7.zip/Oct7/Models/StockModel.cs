﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_XYZ_Apparels.Models
{
    public class StockModel
    {
        public int FabricID { get; set; }
        public string SupplierName { get; set; }
        public string MillName { get; set; }
        public string FabricType { get; set; }
        public string DesignNo { get; set; }
        public int RatePerMeter { get; set; }
        public int StockInMeter { get; set; }
        public string FabricImageAddress { get; set; }
    }
}