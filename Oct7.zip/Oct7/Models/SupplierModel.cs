﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_XYZ_Apparels.Models
{
    public class SupplierModel
    {
        public int SupplierID { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string SupplierName { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string MillName { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string SupplierAddress { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string SupplierWebsite { get; set; }

        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string SupplierEmailID { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string SupplierLandline { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string SupplierContactName1 { get; set; }

        [RegularExpression("^[7-9][0-9]{9}$", ErrorMessage = "Invalid Mobile Number")]
        public string SupplierContactNumber1 { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string SupplierContactName2 { get; set; }

        [RegularExpression("^[7-9][0-9]{9}$", ErrorMessage = "Invalid Mobile Number")]
        public string SupplierContactNumber2 { get; set; }

        [StringLength(9, MinimumLength = 9, ErrorMessage = "9 chars Required")]
        public string SupplierTIN { get; set; }

        [StringLength(15, MinimumLength = 15, ErrorMessage = "15 chars Required")]
        public string SupplierGSTNo { get; set; }

        [StringLength(10, MinimumLength = 10, ErrorMessage = "10 chars Required")]
        public string SupplierPAN { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string SupplierBankName { get; set; }

        [StringLength(17, MinimumLength = 11, ErrorMessage = "11 to 17 chars only")]
        public string SupplierBankAccountNo { get; set; }

        [StringLength(11, MinimumLength = 11, ErrorMessage = "11 chars Required")]
        public string SupplierIFSC { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Min Rs 0")]
        public int SupplierDue { get; set; }

        public string SupplierStatus { get; set; }
    }
}