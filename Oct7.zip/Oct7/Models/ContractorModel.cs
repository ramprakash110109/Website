﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_XYZ_Apparels.Models
{
    public class ContractorModel
    {
        public int ContractorID { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string ContractorName { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string ContractorAddress { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string ContractorWebsite { get; set; }

        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string ContractorEmailID { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string ContractorLandline { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string ContractorContactName1 { get; set; }

        [RegularExpression("^[7-9][0-9]{9}$", ErrorMessage = "Invalid Mobile Number")]
        public string ContractorContactNumber1 { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string ContractorContactName2 { get; set; }

        [RegularExpression("^[7-9][0-9]{9}$", ErrorMessage = "Invalid Mobile Number")]
        public string ContractorContactNumber2 { get; set; }

        [StringLength(9, MinimumLength = 9, ErrorMessage = "9 chars Required")]
        public string ContractorTIN { get; set; }

        [StringLength(15, MinimumLength = 15, ErrorMessage = "15 chars Required")]
        public string ContractorGSTNo { get; set; }

        [StringLength(10, MinimumLength = 10, ErrorMessage = "10 chars Required")]
        public string ContractorPAN { get; set; }

        [StringLength(30, MinimumLength = 5, ErrorMessage = "5 to 30 chars only")]
        public string ContractorBankName { get; set; }

        [StringLength(17, MinimumLength = 11, ErrorMessage = "11 to 17 chars only")]
        public string ContractorBankAccountNo { get; set; }

        [StringLength(11, MinimumLength = 11, ErrorMessage = "11 chars Required")]
        public string ContractorIFSC { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Min Rs 0")]
        public int ContractorDue { get; set; }

        public string ContractorStatus { get; set; }
    }
}