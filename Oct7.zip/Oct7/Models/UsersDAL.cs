﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Mvc;
using System.Configuration;
using System.Web.Security;

namespace Mvc_XYZ_Apparels.Models
{
    public class UsersDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool LoginDAL(LoginModel model)
        {
            SqlCommand com_login = new SqlCommand(@"select count(*) from users where userid=@UserID and userpassword=@UserPassword", con);
            com_login.Parameters.AddWithValue("@UserID", model.UserID);
            com_login.Parameters.AddWithValue("@UserPassword", model.UserPassword);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool AddUser(UserModel obj)
        {
            SqlCommand com_user_insert = new SqlCommand
            (@"insert Users1 values(@UserID,@UserType)", con);

            com_user_insert.Parameters.AddWithValue("@UserID", obj.UserID);
            com_user_insert.Parameters.AddWithValue("@UserType", obj.UserType);
            con.Open();
            com_user_insert.ExecuteNonQuery();

            MembershipCreateStatus status;

            Membership.CreateUser(obj.UserID.ToString(), obj.UserPassword, obj.UserEmailID,
                obj.UserQuestion, obj.UserAnswer, true, out status);

            if (status == MembershipCreateStatus.Success)
            {
                con.Close();
                return true;
            }
            con.Close();
            return false;
        }

        public bool Login(UserModel model)
        {
            return (Membership.ValidateUser(model.UserID.ToString(), model.UserPassword));
        }

        public List<UserModel> GetUsers()
        {
            List<UserModel> list_users = new List<UserModel>();
            SqlCommand com_users = new SqlCommand("Select * from Users1", con);
            con.Open();
            SqlDataReader dr_user = com_users.ExecuteReader();
            while (dr_user.Read())
            {
                UserModel model = new UserModel();
                model.UserID = dr_user.GetString(0);
                model.UserType = dr_user.GetString(1);
                list_users.Add(model);
            }
            con.Close();
            return list_users;
        }
    }
}